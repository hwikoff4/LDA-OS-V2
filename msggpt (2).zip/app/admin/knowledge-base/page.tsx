import { KnowledgeBaseManager } from "@/components/knowledge-base-manager"

export default function KnowledgeBasePage() {
  return <KnowledgeBaseManager />
}
