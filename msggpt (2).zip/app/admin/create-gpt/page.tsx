import { CreateGPTForm } from "@/components/create-gpt-form"

export default function CreateGPTPage() {
  return <CreateGPTForm />
}
